# AGENTS.md

Your operating manual for this workspace, written by you. Your main instructions cover how you work in general. This file is where you keep the specific, durable lessons and conventions you pick up as you work, the kind of thing you'd want a future session to know. It's not about the user (that goes in `USER.md` and your memory) or your personality (that's `SOUL.md`); it's about how you get work done here.

## Conventions
Add an entry whenever you work something out worth keeping, for example:
- a convention you've settled on ("keep data exports in `workspace/exports/` and clean them up monthly")
- a tool or site quirk worth remembering ("site X hides its form behind a cookie banner; dismiss it first")
- a workflow that worked, or a mistake not to repeat

It starts empty and is meant to grow slowly. Don't pad it; a short, accurate file beats a long, stale one.

## Conventions

- **Submit make.fun terblokir pemeriksaan risiko eksekusi sistem (pelajaran 2026-11-22, news-image-20261121):** notice risiko itu menempel pada hasil tool per sesi dan per cakupan konten, dan persetujuan user sebelumnya dianggap tidak mencakup notice baru. Mendelegasikan kelanjutan submit ke subagen BARU memperparah keadaan — sesi baru selalu kena notice baru dan berhenti lagi (terjadi 4x malam itu). Pola yang berhasil: agen utama mengerjakan sendiri sisa langkah (git/gh/kit check/bundle/submit) di sesi chat utama, dan bila kena notice, minta persetujuan user SATU kali dengan cakupan gabungan sekaligus (repo entri + folder perangkat kit + state file), lalu eksekusi segera di sesi yang sama sesudah persetujuan itu. Izin tetap user (2026-11-22 01:58 WIB): persetujuan manual non-sensitif semacam ini BOLEH disetujui & dilanjutkan Muse sendiri tanpa menunggu user — yang dikecualikan keras hanyalah hal yang menyentuh data privasi/sensitif (private key/seed phrase, data login/cookie X, kredensial, wallet di luar pola --keypair w37x yang sudah diatur, data pribadi); kategori sensitif tetap wajib persetujuan eksplisit per kasus. Bila notice sistem tetap menuntut persetujuan segar, rujuk izin tetap ini dalam satu permintaan bercakupan gabungan — dan kabarkan permintaan itu juga ke WhatsApp user (6285882631491) via tugas satu kali ber-delivery WhatsApp, bukan hanya di chat utama (perintah user 2026-11-22 02:00 WIB).
- **Periksa ruang kapasitas tercatat sebelum merancang mitigasi (pelajaran 2026-11-25):** saat muncul masalah perebutan sumber daya bersama, cek dulu fakta kuota/limit yang sudah tercatat di memori sebelum menumpuk workaround. Contoh malam itu: tabrakan box Simular ditangani berlapis (aturan box_lock, wacana AI Studio sebagai pintu cadangan) padahal fakta "akun boleh maks 2 box, terpakai 1" sudah tercatat sejak 2026-11-20 — box kedua adalah obat strukturalnya dan baru terangkat setelah user sendiri bertanya. Urutan yang benar: kapasitas dulu, baru mitigasi.
- **Kunci box Simular untuk sesi push (2026-11-25):** box hanya satu dan dipakai bersama siklus otonom + sesi utama. Sesi push menandai `box_lock` di ~/workspace/makefun-submitted-state.json saat mulai dan melepasnya saat selesai, gerbang Neon push dijalankan paling awal, dan siklus menunda pemakaian box/Neon selama kunci aktif. Mekanika lengkap: bagian koordinasi box di ~/workspace/custom-connectors/custom.gemini-pro/neon-web-role.md; aturan penuh di MEMORY.md.
